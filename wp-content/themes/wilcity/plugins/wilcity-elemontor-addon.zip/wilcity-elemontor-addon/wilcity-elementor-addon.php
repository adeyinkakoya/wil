<?php
/*
 * Plugin Name: Wilcity Elementor Addon
 * Plugin URI: https://wilcity.com
 * Author: Wiloke
 * Author URI: https://wiloke.com
 * Version: 1.0.7
 */

define('WILCITY_EL_PREFIX', 'WILCITY ');

require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
//var_export($_GET);die();
add_filter( 'script_loader_tag', function( $tag, $handle ) {
	if ( isset( $_REQUEST['action'] ) && 'elementor' === $_REQUEST['action'] ) {
		return str_replace( ' src', ' data-cfasync="false" src', $tag );
	}
	return $tag;
}, 10, 2 );

new \WILCITY_ELEMENTOR\Registers\Init();
