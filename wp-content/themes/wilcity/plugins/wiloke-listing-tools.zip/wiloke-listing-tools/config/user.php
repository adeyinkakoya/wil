<?php
return [
	'stripeCustomerID' => 'stripe_customer_id',
	'userPlans'     => 'user_plans',
	'usedTrialPlans'=> 'used_trial_plans'
];