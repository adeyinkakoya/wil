<?php
return array(
	'sessionClaimID' => 'session_claim_id'
);