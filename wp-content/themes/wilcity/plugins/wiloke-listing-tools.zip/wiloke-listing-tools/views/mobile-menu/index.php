<div id="wiloke-mobile-menu-settings">
	<div class="semantic-tabs ui top attached tabular menu">
		<div class="active item" data-tab="main-menu-settings">Bottom Tab Navigator</div>
		<div class="item" data-tab="secondary-menu-settings">Secondary Navigator</div>
	</div>

	<?php require_once plugin_dir_path(__FILE__) . 'settings.php'; ?>
	<?php require_once plugin_dir_path(__FILE__) . 'secondary-menu.php'; ?>
</div>