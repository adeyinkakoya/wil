<div id="wiloke-lineicon-popup" class="ui fullscreen scrolling modal">
    <i class="close icon"></i>
    <!-- header -->
    <div class="header wil-gray">

        <div class="ui one column grid">
            <div class="column">
                <div class="search-form-wrap">
                    <div class="ui input fluid">
                        <input id="wiloke-search-icon" type="text" placeholder="Icon search...">
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- //header -->

    <!-- content -->
    <div class="content scrolling">

        <!-- icons -->
        <div id="wiloke-icon-content" class="wil-container">

        </div>
        <!-- //icons -->

        <div class="ui hidden divider"></div>
    </div>
    <!-- //content -->
</div>