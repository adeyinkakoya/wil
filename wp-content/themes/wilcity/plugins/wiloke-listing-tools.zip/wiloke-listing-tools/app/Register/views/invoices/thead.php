<thead>
	<tr>
        <th class="invoices-id manage-column check-column">
            <input type="checkbox" name="wilcity_checkall" class="wiloke_checkall">
        </th>
		<th class="invoices-id manage-column check-column">#</th>
		<th class="invoices-package manage-column"><?php esc_html_e('Customer', 'wiloke-listing-tools'); ?></th>
		<th class="invoices-package manage-column"><?php esc_html_e('Payment ID', 'wiloke-listing-tools'); ?></th>
		<th class="invoices-package manage-column"><?php esc_html_e('Plan', 'wiloke-listing-tools'); ?></th>
		<th class="invoices-package manage-column"><?php esc_html_e('Gateway', 'wiloke-listing-tools'); ?></th>
		<th class="invoices-package manage-column"><?php esc_html_e('Sub Total', 'wiloke-listing-tools'); ?></th>
		<th class="invoices-package manage-column"><?php esc_html_e('Discount', 'wiloke-listing-tools'); ?></th>
		<th class="invoices-package manage-column"><?php esc_html_e('Total', 'wiloke-listing-tools'); ?></th>
		<th class="invoices-date manage-column"><?php esc_html_e('Date', 'wiloke-listing-tools'); ?></th>
	</tr>
</thead>