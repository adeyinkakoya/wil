<?php

namespace WilokeListingTools\Controllers;


class NextBillingPaymentController {
	public function __construct() {
//		add_action('wiloke-submission/updated-new-user-plan', array($this, 'updateNextBillingPayment'));
	}

	public function updateNextBillingPayment(){

	}
}