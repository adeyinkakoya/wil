<?php
use WILCITY_SC\SCHelpers;
use WilokeListingTools\Framework\Helpers\General;

$aPricingOptions = array('Depends on Listing Type Request'=>'flexible');
$aPostTypes = array('listing'=>'listing');
$aAllPostTypes = array('post'=>'post', 'listing'=>'listing');

if ( class_exists('WilokeListingTools\Framework\Helpers\General') ){
	$aPostTypes = General::getPostTypeKeys(false, false);
	$aPostTypes = array_combine($aPostTypes, $aPostTypes);
	$aPricingOptions = $aPricingOptions + $aPostTypes;

	$aAllPostTypes = General::getPostTypeKeys(true, false);
	$aAllPostTypes = array_combine($aAllPostTypes, $aAllPostTypes);
}

$aContactForm['No contact forms found'] = 0;
if ( defined('WPCF7_VERSION') ){
	$cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );
	$aContactForm = array();
	if ( $cf7 ) {
		foreach ( $cf7 as $cform ) {
			$aContactForm[ $cform->post_title ] = $cform->ID;
		}
	}
}

return [
	array(
		'name'  => 'Heading',
		'base'  => 'wilcity_vc_heading',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'    => array(
			array(
				'type'          => 'textfield',
				'param_name'    => 'blur_mark',
				'heading'       => 'Blur Mark',
				'std'         => '',
				'save_always'   => true
			),
			array(
				'type'          => 'colorpicker',
				'param_name'    => 'blur_mark_color',
				'heading'       => 'Blur Mark Color',
				'std'         => '',
				'save_always'   => true
			),
			array(
				'type'          => 'textfield',
				'param_name'    => 'heading',
				'heading'       => 'Heading',
				'std'         => '',
				'save_always'   => true
			),
			array(
				'type'          => 'colorpicker',
				'param_name'    => 'heading_color',
				'heading'       => 'Heading Color',
				'std'           => '#252c41',
				'save_always'   => true
			),
			array(
				'type'          => 'textarea',
				'param_name'    => 'description',
				'heading'       => 'Description',
				'std'           => '',
				'save_always'   => true
			),
			array(
				'type'          => 'colorpicker',
				'param_name'    => 'description_color',
				'heading'       => 'Description Color',
				'std'           => '#70778b',
				'save_always'   => true
			),
			array(
				'type'          => 'dropdown',
				'param_name'    => 'alignment',
				'heading'       => 'Alignment',
				'std'           => 'wil-text-center',
				'value'	        => array(
					'Center'    => 'wil-text-center',
					'Right'     => 'wil-text-right',
					'Left'      => 'wil-text-left'
				),
				'save_always'   => true
			)
		)
	),
	array(
		'name'  => 'Testimonials',
		'base'  => 'wilcity_vc_testimonials',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'        => array(
			array(
				'param_name'  => 'autoplay',
				'heading'     => 'Auto Play',
				'description' => 'Leave empty to disable this feature. Or specify auto-play each x seconds',
				'type'        => 'textfield',
				'std'         => ''
			),
			array(
				'param_name' => 'testimonials',
				'heading'    => 'Testimonials',
				'type'       => 'param_group',
				'std'        => '',
				'params'     => array(
					array(
						'type' 	    => 'textfield',
						'heading'   => 'Customer Name',
						'param_name'=> 'name'
					),
					array(
						'type' 	    => 'textarea',
						'heading'   => 'Testimonial',
						'param_name'=> 'testimonial'
					),
					array(
						'type'          => 'textfield',
						'heading'       => 'Customer Profesional',
						'param_name' 	=> 'profesional'
					),
					array(
						'type' 	    => 'attach_image',
						'heading'   => 'Avatar',
						'param_name'=> 'avatar'
					)
				)
			)
		)
	),
	array(
		'name'  => 'Wiloke Wave',
        'base'  => 'wilcity_vc_wiloke_wave',
        'icon'  => '',
        'show_settings_on_create' => true,
        'category'  => WILCITY_VC_SC,
        'controls'  => true,
		'params'        => array(
            array(
                'param_name'    => 'heading',
                'heading'       => 'Heading',
                'type'          => 'textfield'
            ),
            array(
                'param_name'    => 'description',
                'heading'       => 'Description',
                'type'          => 'textarea',
                'value'         => ''
            ),
            array(
                'type'          => 'colorpicker',
                'param_name'    => 'left_gradient_color',
                'heading'       => 'Left Gradient Color',
                'save_always'   => true,
                'std'           => '#f06292'
            ),
            array(
                'type'          => 'colorpicker',
                'param_name'    => 'right_gradient_color',
                'heading'       => 'Right Gradient Color',
                'std'           => '#f97f5f',
                'save_always'   => true,
            ),
            array(
                'param_name'  => 'btn_group',
                'heading'     => 'Buttons Group',
                'type'        => 'param_group',
                'value'       => '',
                'params' => array(
                    array(
	                    'type' 	        => 'iconpicker',
	                    'heading'       => 'Icon',
	                    'param_name' 	=> 'icon'
                    ),
                    array(
	                    'type' 	    => 'textfield',
	                    'heading'   => 'Button name',
	                    'param_name'=> 'name'
                    ),
                    array(
	                    'type' 	        => 'textfield',
	                    'heading'       => 'Button URL',
	                    'param_name' 	=> 'url'
                    ),
                    array(
	                    'type' 	        => 'dropdown',
	                    'heading'       => 'Open Type',
	                    'param_name' 	=> 'open_type',
	                    'value' => array(
		                    'In the same window' => '_self',
		                    'In a New Window'    => '_blank'
	                    ),
	                    'std'   => '_self',
	                    'save_always'   => true
                    )
                )
            )
		)
	),
	array(
		'name'  => 'Wiloke Icon',
		'base'  => 'wilcity_vc_box_icon',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'    => array(
			array(
				'param_name'    => 'icon',
				'heading'       => 'Icon',
				'type'          => 'iconpicker',
				'value'         => ''
			),
			array(
				'param_name'    => 'heading',
				'heading'       => 'Heading',
				'type'          => 'textfield',
				'value'         => ''
			),
			array(
				'param_name'  => 'description',
				'heading'     => 'Description',
				'type'        => 'textarea',
				'value'       => ''
			),
		)
	),
	array(
		'name'  => 'Listings Grid Layout',
		'base'  => 'wilcity_vc_listing_grip_layout',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'    => array(
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Tags',
				'param_name'  => 'listing_tags',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Categories',
				'param_name'  => 'listing_cats',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Locations',
				'param_name'  => 'listing_locations',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'type'        => 'dropdown',
				'heading'     => 'Order By',
				'param_name'  => 'orderby',
				'std'         => 'post_date',
				'value'     => array(
					'Listing Date'      => 'post_date',
					'Listing Title'     => 'post_title',
					'Popular Viewed'    => 'best_viewed',
					'Popular Rated'     => 'best_rated',
					'best_shared'       => 'best_shared',
					'Random'            => 'rand',
					'Near By Me'        => 'nearbyme',
					'Premium Listings'  => 'premium_listings',
				),
				'save_always' => true,
			),
			array(
				'type'        => 'textfield',
				'heading'     => 'Radius',
				'description' => 'Fetching all listings within x radius',
				'param_name'  => 'radius',
				'std'         => 10,
				'save_always' => true,
				'dependency'  => array(
					'element' => 'orderby',
					'value'   => array('nearbyme')
				)
			),
			array(
				'type'        => 'dropdown',
				'heading'     => 'Unit',
				'param_name'  => 'unit',
				'dependency'  => array(
					'element'   => 'orderby',
					'value'     => array('orderby', '=', 'nearbyme')
				),
				'value'   => array(
					'KM'        => 'km',
					'Miles'     => 'm'
				),
				'std' => 'km',
				'save_always' => true
			),
			array(
				'type'        => 'textfield',
				'heading'     => 'Tab Name',
				'description' => 'If the grid layout is inside of a tab, we recommend putting the Tab ID to this field. If the tab is emptied, the listings will be shown after the browser is loaded. Otherwise, it will be shown after someone clicks on the Tab Name.',
				'param_name'  => 'tabname',
				'value'       => '',
				'element'     => array(
					'element'   => 'orderby',
					'value'     => array('orderby', '=', 'nearbyme')
				),
				'save_always' => true,
			),
			array(
				'type'        => 'textfield',
				'heading'     => 'Maximum Items',
				'param_name'  => 'posts_per_page',
				'value'		  => 6,
				'save_always' => true
			),
			array(
				'type'        => 'textfield',
				'heading'     => 'Image Size',
				'description' => 'For example: 200x300. 200: Image width. 300: Image height',
				'param_name'  => 'img_size',
				'std'		  => 'wilcity_360x200',
				'save_always' => true
			),
			array(
				'param_name'    => 'maximum_posts_on_lg_screen',
				'heading'         => 'Items / row on >=1200px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1400px ',
				'type'          => 'dropdown',
				'std'           => 'col-lg-4',
				'save_always'   => true,
				'value'		=> array(
					'6 Items / row' => 'col-lg-2',
					'4 Items / row' => 'col-lg-3',
					'3 Items / row' => 'col-lg-4',
					'2 Items / row' => 'col-lg-6',
					'1 Items / row' => 'col-lg-12'
				),
				'group'       => 'Device Settings'
			),
			array(
				'param_name'    => 'maximum_posts_on_md_screen',
				'heading'       => 'Items / row on >=960px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1200px ',
				'type'          => 'dropdown',
				'value'		=> array(
					'6 Items / row' => 'col-md-2',
					'4 Items / row' => 'col-md-3',
					'3 Items / row' => 'col-md-4',
					'2 Items / row' => 'col-md-6',
					'1 Items / row' => 'col-md-12'
				),
				'std'         => 'col-md-3',
				'save_always'   => true,
				'group'       => 'Device Settings'
			),
			array(
				'param_name'    => 'maximum_posts_on_sm_screen',
				'heading'         => 'Items / row on >=720px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 640px ',
				'type'          => 'dropdown',
				'value'		=> array(
					'6 Items / row' => 'col-sm-2',
					'4 Items / row' => 'col-sm-3',
					'3 Items / row' => 'col-sm-4',
					'2 Items / row' => 'col-sm-6',
					'1 Items / row' => 'col-sm-12'
				),
				'std'         => 'col-sm-12',
				'group'       => 'Device Settings',
				'save_always' => true
			)
		)
	),
	array(
		'name'  => 'Hero Search Form',
		'base'  => 'wilcity_vc_search_form',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'        => array(
			array(
				'param_name'    => 'items',
				'heading'       => 'Search Tab',
				'type'          => 'param_group',
				'value'         => '',
				'params'        => array(
					array(
						'param_name'    => 'name',
						'heading'       => 'Tab Name',
						'type'          => 'textfield',
						'std'           => 'Listing',
						'save_always'   => true,
					),
					array(
						'param_name'    => 'post_type',
						'heading'       => 'Directory Type',
						'type'          => 'dropdown',
						'std'           => 'listing',
						'save_always'   => true,
						'value'         => $aPostTypes
					)
				)
			)
		)
	),
	array(
		'name'  => 'Hero',
		'base'  => 'wilcity_vc_hero',
		'is_container' => true,
		'as_parent' => array('only' => 'wilcity_vc_search_form'),
		'content_element' => true,
		'icon'  => '',
		'show_settings_on_create' => false,
		'category'  => WILCITY_VC_SC,
		'params'    => array(
			array(
				'param_name'    => 'heading',
				'heading'       => 'Title',
				'type'          => 'textfield',
				'std'           => 'Explore This City',
				'save_always'   => true,
				'admin_label'   => false
			),
			array(
				'param_name'    => 'heading_color',
				'heading'       => 'Heading Color',
				'type'          => 'colorpicker',
				'save_always'   => true
			),
			array(
				'param_name'    => 'heading_font_size',
				'description'   => 'Eg: 100px',
				'heading'       => 'Heading Font Size',
				'type'          => 'textfield',
				'save_always'   => true
			),
			array(
				'param_name'    => 'description',
				'heading'       => 'Description',
				'type'          => 'textarea',
				'admin_label'   => false
			),
			array(
				'param_name'    => 'description_color',
				'heading'       => 'Description Color',
				'type'          => 'colorpicker',
				'save_always'   => true
			),
			array(
				'param_name'    => 'description_font_size',
				'description'   => 'Eg: 17px',
				'heading'       => 'Description Font Size',
				'type'          => 'textfield',
				'save_always'   => true
			),
			array(
				'param_name'    => 'toggle_button',
				'heading'       => 'Toggle Button',
				'type'          => 'dropdown',
				'admin_label'   => false,
				'std'           => 'enable',
				'save_always'   => true,
				'value'       => array(
					'Enable' => 'enable',
					'Disable'=> 'disable'
				)
			),
			array(
				'param_name'    => 'button_icon',
				'heading'       => 'Button Icon',
				'std'           => 'la la-pencil-square',
				'type'          => 'iconpicker',
				'admin_label'   => false,
				'save_always'   => true,
				'dependency'      => array(
					'element' => 'toggle_button',
					'value'   => array('enable')
				)
			),
			array(
				'param_name'    => 'button_name',
				'heading'       => 'Button Name',
				'std'           => 'Check out',
				'type'          => 'textfield',
				'admin_label'   => false,
				'save_always'   => true,
				'dependency'      => array(
					'element' => 'toggle_button',
					'value'   => array('enable')
				)
			),
			array(
				'param_name'    => 'button_link',
				'heading'       => 'Button Link',
				'type'          => 'textfield',
				'std'           => '#',
				'admin_label'   => false,
				'save_always'   => true,
				'dependency'    => array(
					'element' => 'toggle_button',
					'value'   => array('enable')
				)
			),
			array(
				'param_name'    => 'button_background_color',
				'heading'       => 'Button Background Color',
				'type'          => 'colorpicker',
				'save_always'   => true
			),
			array(
				'param_name'    => 'button_text_color',
				'heading'       => 'Button Text Color',
				'type'          => 'colorpicker',
				'std'           => '#fff',
				'save_always'   => true
			),
			array(
				'param_name'    => 'button_size',
				'heading'       => 'Button Size',
				'type'          => 'dropdown',
				'default'       => 'wil-btn--sm',
				'save_always'   => true,
				'value'      => array(
					'Small' => 'wil-btn--sm',
					'Medium'=> 'wil-btn--md',
					'Large'=> 'wil-btn--lg',
				)
			),
			array(
				'param_name'    => 'toggle_dark_and_white_background',
				'heading'       => 'Toggle Dark and White Background',
				'type'          => 'dropdown',
				'default'       => 'disable',
				'save_always'   => true,
				'value'      => array(
					'Enable' => 'enable',
					'Disable'=> 'disable'
				)
			),
			array(
				'param_name'    => 'bg_overlay',
				'heading'       => 'Background Overlay',
				'type'          => 'colorpicker',
				'default'       => ''
			),
			array(
				'param_name'    => 'bg_type',
				'heading'       => 'Is Using Slider Background?',
				'type'          => 'dropdown',
				'default'       => 'image',
				'value'       => array(
					'Image Background' => 'image',
					'Slider Background'=> 'slider'
				)
			),
			array(
				'param_name'    => 'image_bg',
				'heading'       => 'Background Image',
				'type'          => 'attach_image',
				'save_always'   => true,
				'dependency'      => array(
					'element'   => 'bg_type',
					'value'     => array('image')
				)
			),
			array(
				'param_name'    => 'slider_bg',
				'heading'       => 'Background Slider',
				'type'          => 'attach_images',
				'save_always'   => true,
				'dependency'      => array(
					'element'   => 'bg_type',
					'value'     => array('slider')
				)
			),
			array(
				'param_name'    => 'img_size',
				'heading'       => 'Image Size',
				'type'          => 'textfield',
				'default'       => 'large'
			),
			array(
				'param_name'    => 'search_form_position',
				'heading'       => 'Search Form Style',
				'type'          => 'dropdown',
				'admin_label'   => false,
				'std'           => 'bottom',
				'save_always'   => true,
				'value'       => array(
					'Right of Screen' => 'right',
					'Bottom'    => 'bottom'
				),
				'group' => 'Search Form'
			),
			array(
				'param_name'  => 'search_form_background',
				'heading'     => 'Search Form Background',
				'type'        => 'dropdown',
				'admin_label' => false,
				'std'         => 'hero_formDark__3fCkB',
				'save_always' => true,
				'value'       => array(
					'White' =>'hero_formWhite__3fCkB',
					'Black' => 'hero_formDark__3fCkB'
				),
				'group' => 'Search Form'
			),
			array(
				'param_name'    => 'toggle_list_of_suggestions',
				'heading'       => 'Toggle The List Of Suggestions',
				'description'   => 'A list of suggestion locations/categories will be shown on the Hero section if this feature is enabled.',
				'type'          => 'dropdown',
				'save_always'   => true,
				'value'      => array(
					'Enable' => 'enable',
					'Disable'=> 'disable'
				),
				'std' => 'enable'
			),
			array(
				'param_name'    => 'taxonomy',
				'heading'       => 'Get By',
				'type'          => 'dropdown',
				'save_always'   => true,
				'value'      => array(
					'Listing Category' => 'listing_cat',
					'Listing Location' => 'listing_location'
				),
				'std' => 'listing_cat'
			),
			array(
				'param_name'    => 'orderby',
				'heading'       => 'Order By',
				'type'          => 'dropdown',
				'save_always'   => true,
				'value'      => array(
					'Number of children' => 'count',
					'ID'    => 'id',
					'Slug'  => 'slug',
					'Specify Locations/Categories' => 'specify_terms'
				),
				'std' => 'count'
			),
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Categories',
				'description' => 'This feature is available for Order By Specify Categories',
				'param_name'  => 'listing_cats',
				'save_always' => true,
				'dependence'    => array(
					'element'    => 'taxonomy',
					'value' => array('listing_cat')
				),
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'type'          => 'autocomplete',
				'heading'       => 'Select Locations (Optional)',
				'description'   => 'This feature is available for Order By Specify Locations',
				'param_name'    => 'listing_locations',
				'save_always'   => true,
				'dependence'    => array(
					'element'    => 'taxonomy',
					'value'      => array('listing_locations')
				),
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			)
		),
		'js_view' => 'VcColumnView'
	),
	array(
		'name'  => 'Term Boxes',
		'base'  => 'wilcity_vc_term_boxes',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'    => array(
			array(
				'param_name'   => 'taxonomy',
				'heading'     => 'Taxonomy',
				'type'        => 'dropdown',
				'std'         => 'listing_cat',
				'save_always' => true,
				'value'       => array(
					'Listing Category'  => 'listing_cat',
					'Listing Location'  => 'listing_location',
					'Listing Tag'       => 'listing_tag',
				),
				'admin_label'   => true
			),
			array(
				'type'        => 'autocomplete',
				'heading'       => 'Select Categories (Optional)',
				'description' => 'If this setting is empty, it will get terms by "Order By" setting',
				'param_name'     => 'listing_cats',
				'dependency'    => array(
					'element'   => 'taxonomy',
					'value'     => array('listing_cat')
				),
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'       => 'Select Locations (Optional)',
				'description' => 'If this setting is empty, it will get terms by "Order By" setting',
				'param_name'        => 'listing_locations',
				'dependency'    => array(
					'element'   => 'taxonomy',
					'value'     => array('listing_location')
				),
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'       => 'Select Tags (Optional)',
				'description' => 'If this setting is empty, it will get terms by "Order By" setting',
				'param_name'        => 'listing_tags',
				'dependency'  => array(
					'element'   => 'taxonomy',
					'value'     => array('listing_tag')
				),
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'param_name'  => 'items_per_row',
				'heading'       => 'Items Per Row',
				'type'        => 'dropdown',
				'std'         => 'col-lg-3',
				'save_always' => true,
				'value'       => array(
					'6 Items / row' => 'col-lg-2',
					'4 Items / row' => 'col-lg-3',
					'3 Items / row' => 'col-lg-4',
					'1 Items / row' => 'col-lg-12'
				)
			),
			array(
				'param_name'        => 'orderby',
				'heading'       => 'Order By',
				'description' => 'This feature is not available if the "Select Locations/Select Tags/Select Categories" is not empty',
				'type'        => 'dropdown',
				'std'         => 'count',
				'value'       => array(
					'Number of children' => 'count',
					'Term Name'          => 'name',
					'Term Order'         => 'term_order',
					'Term ID'            => 'id',
					'Term Slug'          => 'slug',
					'Terms Included'     => 'include',
					'None'               => 'none'
				),
				'save_always' => true,
			),
			array(
				'param_name'  => 'order',
				'heading' => 'Order',
				'type'  => 'dropdown',
				'std' => 'DESC',
				'value'   => array(
					'DESC'  => 'DESC',
					'ASC'   => 'ASC'
				),
				'save_always' => true,
			),
			array(
				'param_name'          => 'toggle_box_gradient',
				'heading'         => 'Toggle Box Gradient',
				'description'   => 'In order to use this feature, please upload a Featured Image to each Listing Location/Category: Listings -> Listing Locations / Categories -> Your Location/Category -> Featured Image.',
				'type'          => 'dropdown',
				'std'         => 'disable',
				'value'       => array(
					'Enable' => 'enable',
					'Disable'=> 'disable'
				),
				'group' => 'Box Style',
				'save_always' => true,
			)
		)
	),
	array(
		'name'  => 'Modern Term Boxes',
		'base'  => 'wilcity_vc_modern_term_boxes',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'        => array(
			array(
				'param_name'  => 'taxonomy',
				'heading'     => 'Taxonomy',
				'type'        => 'dropdown',
				'std'         => 'listing_cat',
				'value'       => array(
					'Listing Category'  => 'listing_cat',
					'Listing Location'  => 'listing_location',
					'Listing Tag'       => 'listing_tag',
				),
				'admin_label'   => true,
				'save_always'   => true
			),
			array(
				'type'        => 'autocomplete',
				'heading'       => 'Select Categories (Optional)',
				'description' => 'If this setting is empty, it will get terms by "Order By" setting',
				'param_name'     => 'listing_cats',
				'dependency'    => array(
					'element'   => 'taxonomy',
					'value'     => array('listing_cat')
				),
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				),
				'save_always'   => true
			),
			array(
				'type'        => 'autocomplete',
				'heading'       => 'Select Locations (Optional)',
				'description' => 'If this setting is empty, it will get terms by "Order By" setting',
				'param_name'    => 'listing_locations',
				'dependency'    => array(
					'element'   => 'taxonomy',
					'value'     => array('listing_location')
				),
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				),
				'save_always'   => true
			),
			array(
				'type'        => 'autocomplete',
				'heading'       => 'Select Tags (Optional)',
				'description' => 'If this setting is empty, it will get terms by "Order By" setting',
				'param_name'  => 'listing_tags',
				'dependency'  => array(
					'element'   => 'taxonomy',
					'value'     => array('listing_tag')
				),
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				),
				'save_always'   => true
			),
			array(
				'param_name'  => 'items_per_row',
				'heading'     => 'Items Per Row',
				'type'        => 'dropdown',
				'std'         => 'col-lg-3',
				'value'       => array(
					'6 Items / row' => 'col-lg-2',
					'4 Items / row' => 'col-lg-3',
					'3 Items / row' => 'col-lg-4',
					'1 Items / row' => 'col-lg-12'
				),
				'save_always'   => true
			),
			array(
				'param_name'  => 'col_gap',
				'heading'     => 'Col Gap',
				'type'        => 'textfield',
				'std'         => 20,
				'save_always'   => true
			),
			array(
				'param_name'    => 'image_size',
				'heading'       => 'Image Size',
				'description'   => 'You can use the defined image sizes like: full, large, medium, wilcity_560x300 or 400,300 to specify the image width and height.',
				'type'          => 'textfield',
				'std'           => 'wilcity_560x300',
				'save_always'   => true
			),
			array(
				'param_name'  => 'orderby',
				'heading'     => 'Order By',
				'description' => 'This feature is not available if the "Select Locations/Select Tags/Select Categories" is not empty',
				'type'        => 'dropdown',
				'std'         => 'count',
				'value'       => array(
					'Number of children' => 'count',
					'Term Name'          => 'name',
					'Term Order'         => 'term_order',
					'Term ID'            => 'id',
					'Term Slug'          => 'slug',
					'Terms Included'     => 'include',
					'None'               => 'none'
				),
				'save_always'   => true
			),
			array(
				'param_name'  => 'order',
				'heading' => 'Order',
				'type'  => 'dropdown',
				'std' => 'DESC',
				'value'   => array(
					'DESC'  => 'DESC',
					'ASC'   => 'ASC'
				),
				'save_always'   => true
			)
		)
	),
	array(
		'name'  => 'Listings Slider',
		'base'  => 'wilcity_vc_listings_slider',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'   => array(
			array(
				'param_name'    => 'heading',
				'heading'       => 'Heading',
				'type'          => 'textfield',
				'std'           => 'The Latest Listings',
				'admin_label'   => true
			),
			array(
				'param_name'    => 'desc',
				'heading'       => 'Description',
				'type'          => 'textarea',
				'admin_label'   => true
			),
			array(
				'param_name'    => 'post_type',
				'heading'       => 'Post Type',
				'type'          => 'dropdown',
				'value'		    => $aAllPostTypes,
				'std'           => 'listing',
				'admin_label'   => true
			),
			array(
				'type'          => 'autocomplete',
				'heading'       => 'Select Tags',
				'param_name'    => 'listing_tags',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups'    => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Categories',
				'param_name'  => 'listing_cats',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups'    => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Locations',
				'param_name'  => 'listing_locations',
				'settings'    => array(
					'multiple'  => true,
					'sortable'  => true,
					'groups'    => true,
				)
			),
			array(
				'type'          => 'dropdown',
				'heading'       => 'Order By',
				'param_name'    => 'orderby',
				'value'     => array(
					'Listing Date'      => 'post_date',
					'Listing Title'     => 'post_title',
					'Popular Viewed'    => 'best_viewed',
					'Popular Rated'     => 'best_rated',
					'Best Shared'       => 'best_shared',
					'Premium Listings'  => 'premium_listings',
					'Random'            => 'rand'
				)
			),
			array(
				'param_name'    => 'maximum_posts',
				'heading'       => 'Maximum Listings',
				'type'          => 'textfield',
				'std'           => 8,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'desktop_image_size',
				'heading'       => 'Desktop Image Size',
				'description'   => 'You can use the defined image sizes like: full, large, medium, wilcity_560x300 or 400,300 to specify the image width and height.',
				'type'          => 'textfield',
				'std'           => '',
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_extra_lg_screen',
				'heading'       => 'Items on >=1600px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1600px ',
				'type'          => 'textfield',
				'std'           => 6,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_lg_screen',
				'heading'       => 'Items on >=1400px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1400px ',
				'type'          => 'textfield',
				'std'           => 5,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_md_screen',
				'heading'       => 'Items on >=1200px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1200px ',
				'type'          => 'textfield',
				'std'           => 5,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_sm_screen',
				'heading'       => 'Items on >=992px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 992px ',
				'type'          => 'textfield',
				'std'           => 2,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_extra_sm_screen',
				'heading'       => 'Items on >=640px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 640px ',
				'type'          => 'textfield',
				'std'           => 1,
				'save_always'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'is_auto_play',
				'heading'       => 'Is Auto Play',
				'type'          => 'dropdown',
				'value'         => array(
					'Enable'    => 'enable',
					'Disable'   => 'disable'
				),
				'std'           => 'disable',
				'save_always'   => true,
				'group'         => 'Slider Configuration'
			)
		)
	),
	array(
		'name'  => 'Events Slider',
		'base'  => 'wilcity_vc_events_slider',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'   => array(
			array(
				'param_name'    => 'heading',
				'heading'       => 'Heading',
				'type'          => 'textfield',
				'std'           => 'The Latest Listings',
				'admin_label'   => true
			),
			array(
				'param_name'    => 'desc',
				'heading'       => 'Description',
				'type'          => 'textarea',
				'admin_label'   => true
			),
			array(
				'type'          => 'autocomplete',
				'heading'       => 'Select Tags',
				'param_name'    => 'listing_tags',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups'    => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Categories',
				'param_name'  => 'listing_cats',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups'    => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Locations',
				'param_name'  => 'listing_locations',
				'settings'    => array(
					'multiple'  => true,
					'sortable'  => true,
					'groups'    => true,
				)
			),
			array(
				'type'          => 'dropdown',
				'heading'       => 'Order By',
				'param_name'    => 'orderby',
				'value'     => array(
					'Event Date'      => 'post_date',
					'Event Title'     => 'post_title',
					'Menu Order'      => 'menu_order',
					'Upcoming Event'  => 'upcoming_event',
					'Happening Event' => 'happening_event'
				)
			),
			array(
				'param_name'    => 'maximum_posts',
				'heading'       => 'Maximum Listings',
				'type'          => 'textfield',
				'std'           => 8,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'desktop_image_size',
				'heading'       => 'Desktop Image Size',
				'description'   => 'You can use the defined image sizes like: full, large, medium, wilcity_560x300 or 400,300 to specify the image width and height.',
				'type'          => 'textfield',
				'std'           => '',
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_extra_lg_screen',
				'heading'       => 'Items on >=1600px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1600px ',
				'type'          => 'textfield',
				'std'           => 6,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_lg_screen',
				'heading'       => 'Items on >=1400px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1400px ',
				'type'          => 'textfield',
				'std'           => 5,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_md_screen',
				'heading'       => 'Items on >=1200px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1200px ',
				'type'          => 'textfield',
				'std'           => 5,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_sm_screen',
				'heading'       => 'Items on >=992px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 992px ',
				'type'          => 'textfield',
				'std'           => 2,
				'admin_label'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'maximum_posts_on_extra_sm_screen',
				'heading'       => 'Items on >=640px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 640px ',
				'type'          => 'textfield',
				'std'           => 1,
				'save_always'   => true,
				'group'         => 'Listings On Screen'
			),
			array(
				'param_name'    => 'is_auto_play',
				'heading'       => 'Is Auto Play',
				'type'          => 'dropdown',
				'value'         => array(
					'Enable'    => 'enable',
					'Disable'   => 'disable'
				),
				'std'           => 'disable',
				'save_always'   => true,
				'group'         => 'Slider Configuration'
			)
		)
	),
	array(
		'name'  => 'Pricing Table (Listing Packages)',
		'base'  => 'wilcity_vc_pricing',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params' => array(
			array(
				'param_name'    => 'row',
				'heading'       => 'Items / Row',
				'type'          => 'dropdown',
				'admin_label'   => true,
				'value' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
					'3 Items / Row' => 'col-md-4 col-lg-4',
					'4 Items / Row' => 'col-md-3 col-lg-3',
					'2 Items / Row' => 'col-md-6 col-lg-6'
				),
				'std' => 'col-md-4 col-lg-4',
				'save_always' => true
			),
			array(
				'param_name'    => 'listing_type',
				'heading'       => 'Post Type',
				'type'          => 'dropdown',
				'admin_label'   => true,
				'value'       => $aPricingOptions,
				'save_always' => true
			)
		)
	),
	array(
		'name'  => 'Contact Us',
		'base'  => 'wilcity_vc_contact_us',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'    => array(
			array(
				'param_name'    => 'contact_info_heading',
				'heading'       => 'Heading',
				'type'          => 'textfield',
				'std'           => 'Contact Info',
				'save_always'   => true
			),
			array(
				'param_name'    => 'contact_info',
				'heading'       => 'Contact Info',
				'type'          => 'param_group',
				'std'           => '',
				'params' => array(
					array(
						'type' 	        => 'iconpicker',
						'heading'       => 'Icon',
						'admin_label'   => true,
						'param_name' 	=> 'icon'
					),
					array(
						'type' 	        => 'textarea',
						'heading'       => 'Info',
						'param_name' 	=> 'info'
					),
					array(
						'type' 	        => 'textfield',
						'heading'       => 'link',
						'description'   => 'Enter in # if it is not a real link.',
						'param_name' 	=> 'link'
					),
					array(
						'type' 	=> 'dropdown',
						'heading' => 'Type',
						'param_name' 	=> 'type',
						'std' 	=> 'default',
						'value' => array(
							'Default'   => 'default',
							'Phone'     => 'phone',
							'Email'     => 'mail'
						)
					),
					array(
						'type' 	        => 'dropdown',
						'heading'       => 'Open Type',
						'description'   => 'After clicking on this link, it will be opened in',
						'param_name' 	=> 'target',
						'std' => '_self',
						'value' => array(
							'Self page'  => '_self',
							'New Window' => '_blank'
						)
					)
				),
				'save_always'   => true
			),
			array(
				'param_name'    => 'contact_form_heading',
				'heading'       => 'Heading',
				'type'          => 'textfield',
				'std'           => 'Contact Us',
				'group'         => 'Contact Form',
				'save_always'   => true
			),
			array(
				'type'          => 'dropdown',
				'param_name'    => 'contact_form_7',
				'heading'       => 'Contact Form 7',
				'value'         => $aContactForm,
				'group'         => 'Contact Form',
				'save_always'   => true
			)
		)
	),
	array(
		'name'  => 'Intro Box',
		'base'  => 'wilcity_vc_intro_box',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'        => array(
			array(
				'param_name'    => 'bg_img',
				'heading'         => 'Background Image',
				'type'          => 'attach_image',
				'value'         => ''
			),
			array(
				'param_name'    => 'video_intro',
				'heading'       => 'Video Intro',
				'type'          => 'textfield',
				'value'         => ''
			),
			array(
				'param_name'    => 'content',
				'heading'       => 'Intro',
				'type'          => 'textarea_html',
				'value'         => ''
			)
		)
	),
	array(
		'name'  => 'Team Intro Slider',
		'base'  => 'wilcity_vc_team_intro_slider',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'        => array(
			array(
				'param_name'  => 'get_by',
				'heading'     => 'Get users who are',
				'type'        => 'dropdown',
				'std'         => 'administrator',
				'save_always' => true,
				'value'       => array(
					'Administrator' => 'administrator',
					'Editor'        => 'editor',
					'Contributor'   => 'contributor',
					'Custom'        => 'custom'
				)
			),
			array(
				'param_name'    => 'members',
				'heading'       => 'Members',
				'dependency'    => array(
					'element'   => 'get_by',
					'value'     => array('custom')
				),
				'type'    => 'param_group',
				'std'     => '',
				'params'  => array(
					array(
						'type' 	        => 'attach_image',
						'heading'       => 'Avatar',
						'param_name' 	=> 'avatar'
					),
					array(
						'type' 	        => 'attach_image',
						'heading'       => 'Picture',
						'param_name' 	=> 'picture'
					),
					array(
						'type' 	        => 'textfield',
						'heading'       => 'Name',
						'param_name' 	=> 'display_name'
					),
					array(
						'type' 	        => 'textfield',
						'heading'       => 'Position',
						'param_name' 	=> 'position'
					),
					array(
						'type' 	        => 'textarea',
						'heading'       => 'Intro',
						'param_name' 	=> 'intro'
					),
					array(
						'param_name'    => 'social_networks',
						'heading'       => 'Social Networks',
						'description'   => 'Eg: facebook:https://facebook.com,google-plus:https://googleplus.com',
						'type'          => 'textarea'
					)
				)
			)
		)
	),
	array(
		'name'  => 'Author Slider',
		'base'  => 'wilcity_vc_author_slider',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'        => array(
			array(
				'param_name'    => 'role__in',
				'label'         => 'Role in',
				'description'   => 'Limit the returned users that have one of the specified roles',
				'type'          => 'checkbox',
				'is_multiple'   => true,
				'save_always'   => true,
				'std'         => 'administrator,contributor',
				'value'       => array(
					'Administrator' => 'administrator',
					'Editor'        => 'editor',
					'Contributor'   => 'contributor',
					'Subscriber'    => 'subscriber'
				)
			),
			array(
				'param_name'    => 'orderby',
				'label'         => 'Order by',
				'type'          => 'dropdown',
				'save_always'   => true,
				'std'         => 'post_count',
				'value'       => array(
					'Registered' => 'registered',
					'Post Count' => 'post_count',
					'ID'         => 'ID'
				)
			),
			array(
				'param_name'    => 'number',
				'label'         => 'Maximum Users',
				'save_always'   => true,
				'type'          => 'textfield',
				'std'         => 8
			)
		)
	),
	array(
		'name'  => 'Event Grid Layout',
		'base'  => 'wilcity_vc_events_grid',
		'icon'  => '',
		'show_settings_on_create' => true,
		'category'  => WILCITY_VC_SC,
		'controls'  => true,
		'params'    => array(
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Tags',
				'param_name'  => 'listing_tags',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Categories',
				'param_name'  => 'listing_cats',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'type'        => 'autocomplete',
				'heading'     => 'Select Locations',
				'param_name'  => 'listing_locations',
				'settings' => array(
					'multiple' => true,
					'sortable' => true,
					'groups' => true,
				)
			),
			array(
				'type'        => 'dropdown',
				'label'       => 'Order By',
				'param_name'  => 'orderby',
				'value'       => array(
					'Event Date'      => 'post_date',
					'Event Title'     => 'post_title',
					'Menu Order'      => 'menu_order',
					'Upcoming Event'  => 'upcoming_event',
					'Happening Event' => 'happening_event'
				)
			),
			array(
				'type'        => 'textfield',
				'heading'     => 'Maximum Items',
				'param_name'  => 'posts_per_page',
				'value'		  => 6,
				'save_always' => true
			),
			array(
				'type'        => 'textfield',
				'heading'     => 'Image Size',
				'description' => 'For example: 200x300. 200: Image width. 300: Image height',
				'param_name'  => 'img_size',
				'std'		  => 'wilcity_360x200',
				'save_always' => true
			),
			array(
				'param_name'    => 'maximum_posts_on_lg_screen',
				'heading'         => 'Items / row on >=1200px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1400px ',
				'type'          => 'dropdown',
				'std'           => 'col-lg-4',
				'save_always'   => true,
				'value'		=> array(
					'6 Items / row' => 'col-lg-2',
					'4 Items / row' => 'col-lg-3',
					'3 Items / row' => 'col-lg-4',
					'2 Items / row' => 'col-lg-6',
					'1 Items / row' => 'col-lg-12'
				),
				'group'       => 'Device Settings'
			),
			array(
				'param_name'    => 'maximum_posts_on_md_screen',
				'heading'       => 'Items / row on >=960px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 1200px ',
				'type'          => 'dropdown',
				'value'		=> array(
					'6 Items / row' => 'col-md-2',
					'4 Items / row' => 'col-md-3',
					'3 Items / row' => 'col-md-4',
					'2 Items / row' => 'col-md-6',
					'1 Items / row' => 'col-md-12'
				),
				'std'         => 'col-md-3',
				'save_always' => true,
				'group'       => 'Device Settings'
			),
			array(
				'param_name'    => 'maximum_posts_on_sm_screen',
				'heading'       => 'Items / row on >=720px',
				'description'   => 'Set number of listings will be displayed when the screen is larger or equal to 640px ',
				'type'          => 'dropdown',
				'value'		=> array(
					'6 Items / row' => 'col-sm-2',
					'4 Items / row' => 'col-sm-3',
					'3 Items / row' => 'col-sm-4',
					'2 Items / row' => 'col-sm-6',
					'1 Items / row' => 'col-sm-12'
				),
				'std'         => 'col-sm-12',
				'group'       => 'Device Settings',
				'save_always' => true
			)
		)
	)
];