<?php
/*
 * Plugin Name: Wilcity WP Bakery Addon
 * Plugin URI: https://wilcity.com
 * Author: Wiloke
 * Author URI: https://wiloke.com
 * Version: 1.0.5
 */

if ( !defined('ABSPATH') ){
	die();
}

if ( !function_exists('vc_map') ){
	return '';
}

define('WILCITY_VC_SC', 'Wilcity');

function wilcityAddVCShortcode($aParams){
	$path = plugin_dir_path(__FILE__) . 'vc_templates/';
	$fileDir = $path.$aParams['base'].'.php';
	if ( is_file($fileDir) ){
		include $fileDir;
	}
}

function wilcityIntegrateWithVC(){
	$aVcShortcodes = include plugin_dir_path(__FILE__) . 'configs/vc-shortcodes.php';
	if ( !empty($aVcShortcodes) )
	{
		foreach ( $aVcShortcodes as $aVcMap )
		{
			$aVcMap['params'][] = array(
				'type'       => 'textfield',
				'heading'    => 'Extra Class',
				'param_name' => 'extra_class',
				'value'      => '',
				'std'        => ''
			);

			if ( !isset($aVcMap['is_remove_css_editor']) || !$aVcMap['is_remove_css_editor'] )
			{
				$aVcMap['params'][] = array(
					'type'          => 'css_editor',
					'heading'       => 'Css',
					'param_name'    => 'css',
					'group'         => 'Design Options'
				);
			}
			vc_map($aVcMap);
			wilcityAddVCShortcode($aVcMap);
		}

	}
}

function wilcityVCParseExtraClass($atts){
	if ( isset($atts['css']) ){
		$atts['extra_class'] = $atts['extra_class'] . ' ' . vc_shortcode_custom_css_class($atts['css'], ' ');
	}
	return $atts;
}

add_filter('wilcity/vc/parse_sc_atts', 'wilcityVCParseExtraClass');
add_action('vc_before_init', 'wilcityIntegrateWithVC');


function wilcityFilterTaxonomyAutoComplete($query, $tag, $param_name){
	global $wpdb;
	$taxonomy = substr($param_name, 0, -1);

	$taxonomyTbl = $wpdb->term_taxonomy;
	$termsTbl    = $wpdb->terms;

	$sql = "SELECT $termsTbl.term_id, $termsTbl.name FROM $termsTbl LEFT JOIN $taxonomyTbl ON ($termsTbl.term_id=$taxonomyTbl.term_id) WHERE $termsTbl.name LIKE '%".esc_sql(trim($query))."%' AND $taxonomyTbl.taxonomy=%s LIMIT 20";

	$aRawResults = $wpdb->get_results(
		$wpdb->prepare(
			$sql,
			$taxonomy
		)
	);

	if ( empty($aRawResults) ){
		return false;
	}

	$aResults = array();
	foreach ($aRawResults as $oTerm){
		$aResults[] = array(
			'label' => $oTerm->name,
			'value' => $oTerm->term_id
		);
	}
	return $aResults;
}
add_filter('vc_autocomplete_wilcity_vc_listing_grip_layout_listing_locations_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_listing_grip_layout_listing_cats_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_listing_grip_layout_listing_tags_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);

add_filter('vc_autocomplete_wilcity_vc_term_boxes_locations_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_term_boxes_listing_cats_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_term_boxes_tags_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);

add_filter('vc_autocomplete_wilcity_vc_modern_term_boxes_listing_locations_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_modern_term_boxes_listing_cats_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_modern_term_boxes_listing_tags_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);

add_filter('vc_autocomplete_wilcity_vc_hero_listing_locations_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_hero_listing_cats_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_hero_listing_tags_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);

add_filter('vc_autocomplete_wilcity_vc_listings_slider_listing_locations_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_listings_slider_listing_cats_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_listings_slider_listing_tags_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);

add_filter('vc_autocomplete_wilcity_vc_events_grid_listing_locations_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_events_grid_listing_cats_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);
add_filter('vc_autocomplete_wilcity_vc_events_grid_listing_tags_callback', 'wilcityFilterTaxonomyAutoComplete', 10, 3);

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Wilcity_Vc_Hero extends WPBakeryShortCodesContainer {
	}
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
	class WPBakeryShortCode_Wilcity_Vc_Search_Form extends WPBakeryShortCode {
	}
}
