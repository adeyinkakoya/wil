<?php
function wilcityVCModernTermBoxes($atts){
	$atts = shortcode_atts(
		array(
			'TYPE'              => 'MODERN_TERM_BOXES',
			'items_per_row'     => 'col-lg-3',
			'taxonomy'          => 'listing_cat',
			'listing_cats'      => '',
			'col_gap'           => 20,
			'listing_locations' => '',
			'image_size'        => 'wilcity_560x300',
			'listing_tags'      => '',
			'orderby'           => 'count',
			'order'             => 'DESC',
			'extra_class'       => ''
		),
		$atts
	);

	$atts = apply_filters('wilcity/vc/parse_sc_atts', $atts);

	ob_start();
	wilcity_sc_render_modern_term_boxes($atts);
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}
add_shortcode('wilcity_vc_modern_term_boxes', 'wilcityVCModernTermBoxes');