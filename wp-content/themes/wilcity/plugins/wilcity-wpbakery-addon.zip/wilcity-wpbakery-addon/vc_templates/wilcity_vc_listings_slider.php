<?php
use \WILCITY_SC\SCHelpers;
function wilcityVCListingsSlider($atts){
	$atts = shortcode_atts(
		array(
			'TYPE'      => 'LISTINGS_SLIDER',
			'maximum_posts'             => 8,
			'maximum_posts_on_extra_lg_screen'=> 6,
			'maximum_posts_on_lg_screen'=> 5,
			'maximum_posts_on_md_screen'=> 5,
			'maximum_posts_on_sm_screen'=> 2,
			'maximum_posts_on_extra_sm_screen'=> 2,
			'heading'                   => '',
			'desc'                      => '',
			'post_type'                 => 'listing',
			'from'                      => 'all',
			'listing_tags'              => '',
			'listing_cats'              => '',
			'listing_locations'         => '',
			'orderby'                   => '',
			'is_auto_play'              => 'disable',
			'desktop_image_size'        => '',
			'extra_class'               => '',
			'css_custom'                => '',
			'css'                       => ''
		),
		$atts
	);

	$atts = apply_filters('wilcity/vc/parse_sc_atts', $atts);

	ob_start();
	wilcity_render_slider($atts);
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode('wilcity_vc_listings_slider', 'wilcityVCListingsSlider');